from django.shortcuts import render
from .models import *
# Create your views here.

def BlogView(request):
    blog = Blog.objects.all()
    context = {
        'post': blog
    }
    return render(request, 'blog.html', context)
def PostView(request, pk):
    blog_pk = Blog.objects.get(pk = pk)
    context = {
        'blog_pk': blog_pk
    }
    return render(request, 'blog_detail.html', context)