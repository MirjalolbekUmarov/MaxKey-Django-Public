from django.db import models
from Account.models import MkUser
# Create your models here.

class Blog(models.Model):
    author = models.ForeignKey(MkUser, on_delete = models.CASCADE)
    title = models.CharField(max_length = 50)
    description = models.TextField()
    image = models.ImageField(null = True, blank = True, upload_to = 'Another/')
    posted_in = models.DateTimeField(auto_now_add = True)
    
    def __str__(self):
        return str(self.title)