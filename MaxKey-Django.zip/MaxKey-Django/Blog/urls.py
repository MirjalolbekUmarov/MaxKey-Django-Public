from django.urls import path
from .views import *

urlpatterns = [
    path('', BlogView, name = 'Blogs'),
    path('<int:pk>/', PostView, name = 'Post'),
]