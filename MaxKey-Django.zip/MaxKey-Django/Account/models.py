from django.db import models
from django.contrib.auth.models import AbstractUser
# Create your models here.

class MkUser(AbstractUser):
    first_name = models.CharField(max_length = 25)
    last_name = models.CharField(max_length = 25, null =True, blank = True)
    username = models.CharField(max_length = 25, unique = True)
    email = models.EmailField(null =True, blank = True)
    create_in = models.DateTimeField(auto_now_add = True)