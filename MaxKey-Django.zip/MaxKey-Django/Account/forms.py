from django.contrib.auth.forms import UserChangeForm, UserCreationForm
from .models import MkUser

class MkUserCreateForm(UserCreationForm):
    class Meta:
        model = MkUser
        fields = ('first_name', 'last_name', 'username', 'email')
class MkUserChangeForm(UserChangeForm):
    class Meta:
        model = MkUser
        fields = ('first_name', 'last_name', 'email')