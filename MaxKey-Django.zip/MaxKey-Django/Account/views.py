from django.shortcuts import render, redirect
from .forms import *
# Create your views here.

def Sign_up(request):
    if request.method == "POST":
        form = MkUserCreateForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    form = MkUserCreateForm
    return render(request, 'registration/signup.html', {
        'form': form
})
def Profile(request):
    return render(request, 'account.html')