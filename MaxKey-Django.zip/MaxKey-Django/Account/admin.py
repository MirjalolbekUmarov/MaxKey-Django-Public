from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .forms import MkUserChangeForm, MkUserCreateForm
from .models import MkUser

# Register your models here.

class MkUserAdmin(UserAdmin):
    add_form = MkUserCreateForm
    form = MkUserChangeForm
    model = MkUser
    list_display = ['username', 'email', 'create_in', 'is_staff']
    # fieldsets = UserAdmin.fieldsets + (
    #     (None, {'fields': ('username',)}),
    # )
    # add_fieldsets = UserAdmin.add_fieldsets + (
    #     (None, {'fields': ('email',)}),
    # )
    
admin.site.register(MkUser, MkUserAdmin)