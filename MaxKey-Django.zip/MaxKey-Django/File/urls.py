from django.urls import path
from .views import *
urlpatterns = [
    path('download/', Home, name = "Home_Files"),
    path('upload/', Upload_file, name = 'Upload_file'),
    path('edit/<int:pk>', Edit_file, name = 'Edit_file'),
    path('delete/<int:pk>', Delete_file, name = 'Delete_file')
]