from django.shortcuts import render, redirect
from .models import *
from .forms import *
# Create your views here.

def Home(request):
    files = File.objects.all()
    return render(request, 'file.html', {'files': files})

def Upload_file(request):
    
    if request.method == 'POST':
        repost = dict(request.POST)
        for x, y in repost.items():
            repost.update({x:y[0]})
        print(repost)
        new_post = {**repost, 'author': request.user}
        form = UploadForm(new_post, request.FILES)
        print(form.is_valid())
        print(form.errors)
        if form.is_valid():
            form.save()
            return redirect('Home_Files')     
    
    form = UploadForm()
    return render(request, 'upload.html', {
        'form': form
    })
    
def Edit_file(request, pk):
    if request.method == 'POST':
        repost = dict(request.POST)
        for x, y in repost.items():
            repost.update({x:y[0]})
        print(repost)
        new_post = {**repost, 'author': request.user}
        form = UploadForm(new_post, request.FILES, instance=File.objects.get(pk=pk))
        print(form.is_valid())
        print(form.errors)
        if form.is_valid():
            form.save()
            return redirect('Home_Files')
    form = UploadForm(instance=File.objects.get(pk=pk))
    file = File.objects.get(pk = pk)
    context = {'file': file, 'form':form}
    return render(request, 'edit_file.html', context)
    
    
def Delete_file(request, pk):
    file = File.objects.get(pk=pk)
    file.delete()
    return redirect('Home_Files')