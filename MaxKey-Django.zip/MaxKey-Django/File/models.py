from django.db import models
from django.contrib.auth.models import User
from Account.models import MkUser
from django.urls import reverse
# Create your models here.

class File(models.Model):
    title = models.CharField(max_length = 20)
    description = models.TextField()
    author = models.ForeignKey(MkUser, on_delete = models.CASCADE)
    file = models.FileField(upload_to = "Files/")

    @property
    def type(self):
        
        return self.title.split('.')[-1]
    
    def __str__(self) -> str:
        return self.title
    @property
    def get_file_name(self):
        return self.file.name.split('/')[-1]
    
    def get_absolute_url(self):
        return reverse('Home_Files')
    
